package com.springsecurity.oauthserversecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthServerSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(OauthServerSecurityApplication.class, args);
	}

}
