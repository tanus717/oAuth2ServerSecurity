package com.springsecurity.oauthserversecurity.entity;

import javax.persistence.Entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
public class Permission extends BaseIdEntity {

	private String name;

}